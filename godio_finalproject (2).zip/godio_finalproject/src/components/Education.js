const Education = () => {
    return (
      <section className="my-12">
        <h2 className="text-3xl font-semibold text-blue-600">Education</h2>
        <p className="text-lg mt-4">Bachelor of Science in Computer Science...</p>
      </section>
    );
  };
  
  export default Education;  // Default export
  