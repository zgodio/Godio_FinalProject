import React from 'react';

const Experience = () => {
  return (
    <section className="my-12">
      <h2 className="text-3xl font-semibold text-blue-600">Experience</h2>
      <p className="text-lg mt-4">
        Frontend Developer at ABC Company, 2021–Present
      </p>
    </section>
  );
};

export default Experience;
