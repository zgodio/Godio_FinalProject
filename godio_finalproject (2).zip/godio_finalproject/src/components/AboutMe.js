import React from 'react';

function AboutMe() {
  return (
    <section className="p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-2">About Me</h2>
      <p>
        Hi! I’m Zarah Godio, a 2nd-year BSIT student majoring in ERP at the University of the Cordilleras. 
        I’m passionate about tech, learning, and building creative solutions like this portfolio.
      </p>
    </section>
  );
}

export default AboutMe;
