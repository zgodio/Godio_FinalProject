import React from 'react';

const Contact = () => {
  return (
    <section className="my-12">
      <h2 className="text-3xl font-semibold text-blue-600">Contact</h2>
      <p className="text-lg mt-4">
        You can reach me at <a href="mailto:email@example.com" className="text-blue-600">email@example.com</a>
      </p>
    </section>
  );
};

export default Contact;
